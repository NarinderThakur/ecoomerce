import admin_thumbnails
from django.contrib import admin
from mptt.admin import DraggableMPTTAdmin
from home.models import sliding_image, Category, Product, Contact, ContactForm, Comment, Size, Color, Variants, Image


class CategoryAdmin(admin.ModelAdmin):
    list_display = ['parent','keyword','create_at']
    list_filter = ['keyword']

class CategoryAdmin2(DraggableMPTTAdmin):
    mptt_indent_field = 'title'
    list_display = ('tree_actions','indented_title','related_products_count','related_products_cumulative_count')
    list_display_links = ('indented_title',)
    prepopulated_fields = {'slug':('title',)}

    def get_queryset(self, request):
        ps = super().get_queryset(request)
        ps = Category.objects.add_related_count(
            ps,
            Product,
            'category',
            'products_cumulative_count',
            cumulative=True
        )

        ps = Category.objects.add_related_count(
            ps,
            Product,
            'category',
            'products_count',
            cumulative=False
        )

        return ps

    def related_products_count(self,instance):
        return instance.products_count
    related_products_count.short_description = 'Realted products (for this sepecific category)'

    def related_products_cumulative_count(self,instance):
        return instance.products_cumulative_count
    related_products_cumulative_count.short_description='Realted products (in tree)'

@admin_thumbnails.thumbnail('image')
class ProductImageInline(admin.TabularInline):
    model = Image
    readonly_fields = ('id',)
    extra = 1

class ProductVariantsInline(admin.TabularInline):
    model = Variants
    extra = 1
    readonly_fields = ('image_tag',)
    show_change_link = True

@admin_thumbnails.thumbnail('image')
class ImageAdmin(admin.ModelAdmin):
    list_display = ['image','title','image_thumbnail']

class ProductAdmin(admin.ModelAdmin):
    list_display = ['title','category','image_tag']
    list_filter = ['category']
    readonly_fields = ('image_tag',)
    inlines = [ProductImageInline,ProductVariantsInline]
    prepopulated_fields = {'slug':('title',)}



class CommentAdmin(admin.ModelAdmin):
    list_display = ['subject','comment','status','create_at']
    list_filter = ['status']
    # readonly_fields = ('subject','comment','ip','user','product','rate')

class ColorAdmin (admin.ModelAdmin):
    list_display = ['name','code','color_tag']

class SizeAdmin (admin.ModelAdmin):
    list_display = ['name','code']


class VariantsAdmin (admin.ModelAdmin):
    list_display = ['title' , 'product' , 'color' , 'size' , 'price' , 'quantity','image_tag']


admin.site.register(sliding_image)
admin.site.register(Category,CategoryAdmin2)
admin.site.register(Product,ProductAdmin)
admin.site.register(Contact)
admin.site.register(Comment,CommentAdmin)
admin.site.register(Image,ImageAdmin)
admin.site.register(Color,ColorAdmin)
admin.site.register(Size,SizeAdmin)
admin.site.register(Variants,VariantsAdmin)
