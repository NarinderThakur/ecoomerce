
from django.urls import path
from .import views


urlpatterns = [
    path('',views.home,name='home'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('search/', views.search, name='search'),
    path('addcomment/<int:id>', views.addcomment, name='addcomment'),
    path('product_list/<int:id>/<slug:slug>', views.product_list, name='product_list'),
    path('show_product/<int:id>/<slug:slug>', views.show_product, name='show_product'),
]
