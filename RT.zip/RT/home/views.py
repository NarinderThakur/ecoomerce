import json
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import render,HttpResponse
from django.template.loader import render_to_string
from home.form import SearchForm
from home.models import Category, Product, ContactForm, Contact, Comment, CommentForm, Variants, Image
from order.models import ShopCart


def home(request):
    current_user = request.user
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    product = Product.objects.all()
    # product_departments = Product.objects.all().order_by('id')[4:10]
    total = 0
    for ps in shopcart:
        total += ps.product.price * ps.quantity
    context = {
               'product':product,
                'shopcart' : shopcart,
                'total':total,
                # 'product_departments':product_departments,
    }
    return render(request,'home.html',context)

def about (request):
    return render(request,'about.html')

def product_list(request,id,slug):
    product = Product.objects.filter(category_id=id)
    context = {
        'product':product,
    }
    return render(request,'shop_list.html',context)

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            data = Contact()
            data.name = form.cleaned_data['name']
            data.email = form.cleaned_data['email']
            data.password = form.cleaned_data['password']
            data.message = form.cleaned_data['message']
            # data.ip = request.META.get['SERVER_NAME']
            data.save()
            # messages.success(request,"Your message has been sent, thanku you")
            return HttpResponseRedirect('/contact')
    form = ContactForm
    contaxt = {'form':form,
              }
    return render(request,'contact.html',contaxt)



def search(request):

    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            product = Product.objects.all()
            current_user = request.user
            shopcart = ShopCart.objects.filter(user_id = current_user.id)

            query = form.cleaned_data['query']
            cat_id = form.cleaned_data['cat_id']
            if cat_id == 0:
                products = Product.objects.filter(title__icontains=query)
            else:
                products = Product.objects.filter(title__icontains=query,category_id=cat_id)

            category = Category.objects.all()

            save_heading = {'products':products,
                            'query':query,
                            'category': category,'product':product,  'shopcart':shopcart
                            }
            return render(request,'search_grid.html',save_heading)
    return HttpResponseRedirect('/')

def error_404_view(request,exception):
    return render(request,'error_404.html')

def addcomment(request,id):
    url = request.META.get('HTTP_REFERER')
    if request.method =="POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            data = Comment()
            data.subject = form.cleaned_data['subject']
            data.comment = form.cleaned_data['comment']
            data.rate = form.cleaned_data['rate']
            data.product_id =id
            current_user = request.user
            data.user_id = current_user.id
            data.save()
            return HttpResponseRedirect(url)
    return HttpResponseRedirect(url)

def show_product(request,id,slug):
    query = request.GET.get('q')
    product = Product.objects.get(pk=id)
    product_related = Product.objects.all()[:6]
    image = Image.objects.filter(product_id = id)
    comment = Comment.objects.filter(product_id=id, status='True')
    context = {'product':product,
               'product_related':product_related,
               'image':image,
               'comment':comment,}

    # if product.variant !="None":
    #     if request.method =="POST":
    #         variant_id = request.POST.get('variantid')
    #         variant = Variants.objects.get(id=variant_id)
    #         colors = Variants.objects.filter(product_id = id, size_id = variant.size_id)
    #         sizes = Variants.objects.raw("SELECT * FROM product_variants WHERE product_id =%s GROUP BY size_id",[id])
    #         query += variant.title + 'Size:' + str(variant.size) + 'Color:' + str(variant.color)
    #     else:
    #         variants = Variants.objects.filter(product_id = id )
    #         colors = Variants.objects.filter(product_id = id,size_id = variants[0].size_id)
    #         sizes = Variants.objects.raw('SELECT * FROM product_variants WHERE product_id=%s GROUP BY size_id', [id])
    #         variant = Variants.objects.get(id = variants[0].id)
    #     context.update({'sizes':sizes,
    #                     'colors':colors,
    #                     'variant':variant,
    #                     'query':query
    #                     })

    return render(request,'show_product.html',context)

def ajaxcolor(request):
    data= {}
    if request.POST.get('action') == 'post':
        size_id = request.POST.get('size')
        productid = request.POST.get('productid')
        color = Variants.objects.filter(product_id=productid, size_id = size_id)
        context = {
            'size_id': size_id,
            'productid': productid,
            'color': color,
        }
        data = {'rendered_table' : render_to_string ('color_list.html',context= context)}
        return JsonResponse(data)
    return JsonResponse(data)








