from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.utils import timezone
from django.utils.crypto import get_random_string
from order.models import ShopCart, ShopCartForm, OrderForm, Order, OrderProduct, PaymentForm, Payment
from user.models import UserProfile
from home.models import Category, Product
from django.contrib import messages

@login_required(login_url='/signup')
def addtoshopcart (request,id):
    url = request.META.get('HTTP_REFERER')
    current_user = request.user

    checkproduct = ShopCart.objects.filter(product_id=id)
    if checkproduct:
        control = 1
    else:
        control = 0

    if request.method =='POST':
        form =ShopCartForm(request.POST)
        if  form.is_valid():
            if control == 1:
                data = ShopCart.objects.get(product_id =id)
                data.quantity += form.cleaned_data['quantity']
                data.save()

            else:
                data = ShopCart()
                data.user_id = current_user.id
                data.product_id = id
                data.quantity = form.cleaned_data['quantity']
                data.save()
        return HttpResponseRedirect(url)
    else:
        if control == 1:
            data = ShopCart.objects.get(product_id=id)
            data.quantity +=1
            data.save()
        else:
            data =ShopCart()
            data.user_id = current_user.id
            data.product_id = id
            data.quantity = 1
            data.save()
        return HttpResponseRedirect(url)

@login_required(login_url='/signup')
def shopcart(request):
    product = Product.objects.all()
    current_user = request.user
    shpcart = ShopCart.objects.filter(user_id = current_user.id)
    total = 0
    for ps in shpcart:
        total += ps.product.price * ps.quantity
    context = {'product':product,
                   'shpcart':shpcart,
                   'total':total,
                   }
    return render(request,'cart.html',context)

@login_required(login_url='/signup')
def deletefromcart(request,id):
    ShopCart.objects.filter(id=id).delete()

    return HttpResponseRedirect('/shopcart')

@login_required(login_url='/signup')
def orderproduct(request):
    current_user = request.user
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    total = 0
    amount = 0
    for ps in shopcart:
        total += ps.product.price * ps.quantity
        amount += ps.product.price


    if request.method =='POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            data = Order()
            data.first_name = form.cleaned_data['first_name']
            data.last_name = form.cleaned_data['last_name']
            data.email = form.cleaned_data['email']
            data.address = form.cleaned_data['address']
            data.country = form.cleaned_data['country']
            data.city = form.cleaned_data['city']
            data.phone = form.cleaned_data['phone']
            data.address = form.cleaned_data['address']
            data.user_id = current_user.id
            data.total = total
            ordercode = get_random_string(5).upper()
            data.code = ordercode
            data.save()

            schopcart = ShopCart.objects.filter(user_id=current_user.id)
            for ps in schopcart:
                detail = OrderProduct()
                detail.order_id = data.id
                detail.product_id = ps.product_id
                detail.user_id = current_user.id
                detail.quantity = ps.quantity
                detail.price = ps.product.price
                detail.amount = ps.amount
                detail.save()

                product = Product.objects.get(id=ps.product_id)
                product.price -= ps.quantity
                product.save()

             # ShopCart.objects.filter(user_id=current_user.id).delete()
            # request.session['cart_items'] = 0
                order = ShopCart.objects.filter(user_id = current_user.id)
                total = 0
                amount = 0
                for ps in order:
                    total += ps.amount
                    amount += ps.price
                # messages.success(request, 'Your Order has been completed. Thakes You')
                return render(request, 'payment.html',{'ordercode':ordercode,'order':order,'total':total,'amount':amount})
        else:
            messages.warning(request, form.errors)
            return HttpResponseRedirect("/order/checkout")

    form = OrderForm()
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    order = OrderProduct.objects.filter(user_id = current_user.id)
    profile = UserProfile.objects.get(user_id=current_user.id)
    context = {'order':order,
               'shopcart':shopcart,
               'profile':profile,
               'form':form,
               'total':total}
    return render(request,'checkout.html',context)

@login_required(login_url='/signup')
def payment(request):
    current_user = request.user
    order = ShopCart.objects.filter(user_id = current_user.id)

    total = 0
    amount = 0
    for ps in order:
        total += ps.amount
        amount += ps.price

# shopcart = ShopCart.objects.filter(user_id = current_user.id)
    # total = 0
    # amount = 0
    # for ps in shopcart:
    #     total += ps.product.price * ps.quantity
    #     amount += ps.product.price

    if request.method =='POST':
        card_number =  request.POST['card_number']
        full_name =  request.POST['full_name']
        last_month =  request.POST['last_month']
        cvc =  request.POST['cvc']

        data = Payment(card_number=card_number, full_name=full_name, last_month=last_month,cvc=cvc)

        data.save()
        messages.success(request, 'Your Order has been completed. Thakes You')
        return HttpResponseRedirect("/order/review")
        # return render(request, 'review.html')
    form = PaymentForm()
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    profile = UserProfile.objects.get(user_id=current_user.id)
    context = {
               'shopcart':shopcart,
               'profile':profile,
               'form':form,

               'total':total}
    return render(request,'payment.html',context)

@login_required(login_url='/signup')
def review(request):
    current_user = request.user
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    profile = UserProfile.objects.filter(user_id = current_user.id)

    payment = Payment.objects.filter(create_at__lte=timezone.now()).order_by('create_at')[:1]
    total = 0
    for ps in shopcart:
        total += ps.product.price * ps.quantity

    context = {'payment':payment,
               'shopcart':shopcart,
               'total':total,
               'profile':profile}
    return render(request,'review.html',context)

@login_required(login_url='/signup')
def thanku(request):
    current_user = request.user
    ShopCart.objects.filter(user_id=current_user.id).delete()
    request.session['cart_items'] = 0
    shopcart = ShopCart.objects.filter(user_id = current_user.id)
    context = {
               'shopcart':shopcart,
               }
    return render(request,'thanku.html',context)