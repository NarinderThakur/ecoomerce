from django.urls import path
from .import views


urlpatterns = [
    path('addtoshopcart/<int:id>', views.addtoshopcart, name='addtoshopcart'),
    path('deletefromcart/<int:id>', views.deletefromcart, name='deletefromcart'),
    path('orderproduct/', views.orderproduct, name='orderproduct'),
    path('payment/', views.payment, name='payment'),
    path('review/', views.review, name='review'),
    path('thanku/', views.thanku, name='thanku'),

]
